from core.llm import call_llm

def plan_goal(goal: str) -> str:
    prompt = f"""
你是一个目标拆解专家，请把以下目标拆解为可执行步骤：

目标：
{goal}

输出格式：
1. xxx
2. xxx
"""
    return call_llm(prompt)
