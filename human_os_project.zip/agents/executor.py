from core.llm import call_llm

def execute_task(task: str) -> str:
    prompt = f"""
你是一个行动执行助手，请给出如何完成以下任务的具体行动建议：

任务：
{task}
"""
    return call_llm(prompt)
