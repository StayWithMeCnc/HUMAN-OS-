from core.llm import call_llm

def review_day(logs: str) -> str:
    prompt = f"""
你是一个复盘专家，请分析今天的行为记录，并给出优化建议：

记录：
{logs}

输出：
- 做得好的地方
- 问题
- 明日优化建议
"""
    return call_llm(prompt)
