import json
from pathlib import Path

MEMORY_PATH = Path("data/memory.json")

def load_memory():
    if not MEMORY_PATH.exists():
        return []
    return json.loads(MEMORY_PATH.read_text())

def save_memory(data):
    MEMORY_PATH.parent.mkdir(parents=True, exist_ok=True)
    MEMORY_PATH.write_text(json.dumps(data, indent=2))

def add_memory(entry):
    data = load_memory()
    data.append(entry)
    save_memory(data)
