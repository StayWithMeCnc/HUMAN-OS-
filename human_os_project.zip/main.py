from fastapi import FastAPI
from pydantic import BaseModel

from agents.planner import plan_goal
from agents.executor import execute_task
from agents.reviewer import review_day
from memory.store import add_memory, load_memory

app = FastAPI()

class GoalRequest(BaseModel):
    goal: str

class TaskRequest(BaseModel):
    task: str

class ReviewRequest(BaseModel):
    logs: str

@app.post("/plan")
def plan(req: GoalRequest):
    result = plan_goal(req.goal)
    add_memory({"type": "plan", "content": result})
    return {"plan": result}

@app.post("/execute")
def execute(req: TaskRequest):
    result = execute_task(req.task)
    add_memory({"type": "execution", "content": result})
    return {"result": result}

@app.post("/review")
def review(req: ReviewRequest):
    result = review_day(req.logs)
    add_memory({"type": "review", "content": result})
    return {"review": result}

@app.get("/memory")
def memory():
    return load_memory()
